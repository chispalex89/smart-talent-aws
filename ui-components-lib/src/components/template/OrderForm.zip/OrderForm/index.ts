import OrderForm from './OrderForm'
import type { OrderFormSchema } from './types'

export type { OrderFormSchema }
export default OrderForm
